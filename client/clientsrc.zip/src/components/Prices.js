export const Prices = [
  {
    _id: 0,
    name: "RS 0 to 10000",
    array: [0, 10000],
  },
  {
    _id: 1,
    name: "RS 10000 to 14000",
    array: [10000, 14000],
  },
  {
    _id: 2,
    name: "Rs 14000 to 20000",
    array: [14000, 20000],
  },
  {
    _id: 3,
    name: "Rs 20000 to 40000",
    array: [20000, 40000],
  },
  // {
  //   _id: 4,
  //   name: "$80 to 99",
  //   array: [80, 99],
  // },
  // {
  //   _id: 4,
  //   name: "$100 or more",
  //   array: [100, 9999],
  // },
];
